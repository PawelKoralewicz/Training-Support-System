export const genderOptions = [
    { label: 'Male', value: 'male' },
    { label: 'Female', value: 'female' }
];