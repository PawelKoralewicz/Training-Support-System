export enum Role {
    AUTHENTICATED = "Authenticated",
    ADMIN = "Admin"
}