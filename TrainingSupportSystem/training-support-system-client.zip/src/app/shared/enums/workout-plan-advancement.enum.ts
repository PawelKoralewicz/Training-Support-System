export enum WorkoutPlanAdvancement {
    BEGINNER = 'beginner',
    INTERMEDIATE = 'intermediate',
    ADVANCED = 'advanced',
    PRO = 'pro'
}