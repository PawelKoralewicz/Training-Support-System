export enum Lifts {
    SQUAT = 'squat',
    BENCH_PRESS = 'bench',
    DEADLIFT = 'deadlift'
}