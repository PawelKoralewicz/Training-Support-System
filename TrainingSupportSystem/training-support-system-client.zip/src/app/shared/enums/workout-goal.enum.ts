export enum WorkoutMainGoal {
    MUSCLE = "muscle",
    STRENGTH = "strength"
}