export enum WorkoutFocus {
    UPPER = "upper",
    LEGS = "legs"
}