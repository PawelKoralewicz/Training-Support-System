import { Component } from '@angular/core';

@Component({
  selector: 'app-training-planner',
  templateUrl: './training-planner.component.html',
  styleUrls: ['./training-planner.component.scss']
})
export class TrainingPlannerComponent {

}
