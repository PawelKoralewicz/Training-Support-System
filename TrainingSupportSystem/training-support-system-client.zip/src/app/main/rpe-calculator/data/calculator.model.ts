export interface ICalculator {
    weight?: number;
    reps?: number;
    rpe?: number;
    lift?: string;
}