export const allergens = [
    'eggs',
    'milk',
    'wheat',
    'nuts',
    'fish',
    'soya',
]