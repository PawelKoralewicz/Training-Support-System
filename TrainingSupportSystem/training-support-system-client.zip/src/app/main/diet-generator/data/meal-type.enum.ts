export enum MealType {
    BREAKFAST = 'breakfast',
    DINNER = 'dinner',
    SUPPER = 'supper'
}