export interface IIngredients {
    ingredientName: string;
    portionSize: number;
}