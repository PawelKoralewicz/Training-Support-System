import { Component } from '@angular/core';

@Component({
  selector: 'app-diet-generator',
  templateUrl: './diet-generator.component.html',
  styleUrls: ['./diet-generator.component.scss']
})
export class DietGeneratorComponent {

}
