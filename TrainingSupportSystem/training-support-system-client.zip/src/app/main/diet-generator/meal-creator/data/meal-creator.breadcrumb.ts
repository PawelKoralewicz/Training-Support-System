import { MenuItem } from "primeng/api";

export const mealCreatorBreadcrumb: MenuItem[] = [
    {
        label: 'Meal creator',
    }
]

export const mealCreatorBreadcrumbHome: MenuItem = {
    routerLink: '/dieting'
}