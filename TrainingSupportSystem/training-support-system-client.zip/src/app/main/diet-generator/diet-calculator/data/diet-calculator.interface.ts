export interface IDietCalculator {
    id?: number;
    gender?: string;
    age?: number;
    height?: number;
    weight?: number;
    activity?: number;
    goal?: string;
}